/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package SessionBean;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author SDH
 */
public class Crudservlett extends HttpServlet {

    @EJB
    private curdtrabajoLocal curdtrabajo;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            // con esto ingreso los datos 
         
            /*
              // CODIGO ANTES DE HABILITAR LOS DOS BOTONES 
            String nombreEmpleado =request.getParameter("nombre_empleado");
            String  CodigoEmpleado =request.getParameter("codigo");
            String cargo =request.getParameter("cargo");
            curdtrabajo.agregarDatos(CodigoEmpleado, nombreEmpleado, cargo);
            //CODIGO CON LOS DOS BOTONES RECORDAR BREINNER NO DESCOMENTAR LO OTRO 
            */
            
              String accion = request.getParameter("accion");
        
        if ("agregar".equals(accion) || "Enviar".equals(accion)) {
            // Manejar la adición de datos
              String CodigoEmpleado = request.getParameter("codigo");
              String  nombreEmpleado = request.getParameter("nombre_empleado");
             String  cargo = request.getParameter("cargo");
            curdtrabajo.agregarDatos(CodigoEmpleado, nombreEmpleado, cargo);
        } else if ("actualizar".equals(accion)) {
            // Manejar la actualización de datos
            int id = Integer.parseInt(request.getParameter("id"));
            String CodigoEmpleado = request.getParameter("codigo");
            String nombreEmpleado = request.getParameter("nombre_empleado");
            String cargo = request.getParameter("cargo");
            curdtrabajo.actualizarDatos(id, CodigoEmpleado, nombreEmpleado, cargo);
        } else if ("borrar".equals(accion)) {
            // Manejar la eliminación de datos
            int id = Integer.parseInt(request.getParameter("id"));
            curdtrabajo.borrarDatos(id);
        }

         
            //probando salida por consola
          /*  System.out.println("CodigoEmpleado: " + CodigoEmpleado);
            System.out.println("NombreEmpleado: " + nombreEmpleado);
            System.out.println("Cargo: " + cargo);
          */
            /* aqui funciona correctamente pero pondre esta informacion ent otro servlet */
            /* 
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Crudservlett</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Lista de empleados</h1>");
            esto es para que aparezca la informazion  en el servlet
            List<String[]> datos = curdtrabajo.obtenerDatos();
            
            out.println("<ul>");  // inicio la lista desordenada
            
            for (int i = 0; i < datos.size(); i++) {
                String[] persona = datos.get(i);
                out.println("<li>ID: " + i + " - Código: " + persona[0] + ", Nombre: " + persona[1] + ", Cargo: " + persona[2] + "</li>");
            }

            out.println("</ul>");  // Cerramos la lista desordenada

            out.println("<h2>Breinner probando  </h2>");
            out.println("</body>");
            out.println("</html>"); 
            */
           
               List<String[]> datos = curdtrabajo.obtenerDatos();
              // Guardar la lista de datos como atributo de la solicitud (request)
                request.setAttribute("listaDatos", datos);
            
        RequestDispatcher dispatcher = request.getRequestDispatcher("mostrarDatos.jsp");
        dispatcher.forward(request, response);
            
            
        }
    }


    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

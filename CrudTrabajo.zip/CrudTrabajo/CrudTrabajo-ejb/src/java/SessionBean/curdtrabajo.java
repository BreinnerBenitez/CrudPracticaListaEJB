/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package SessionBean;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;

/**
 *
 * @author SDH
 */
@Stateless
public class curdtrabajo implements curdtrabajoLocal {

    private List<String[]> listaDatos = new ArrayList<>();
    
    @Override
    public void agregarDatos(String codigo_empleado, String nombre_empleado, String cargo) {
            // Cada entrada es un array de Strings y guarda los datos en el array
        String[] datos = {codigo_empleado,nombre_empleado, cargo};
        listaDatos.add(datos); 
       
    }

    @Override
    public List<String[]> obtenerDatos() {
          return listaDatos;
    }

    @Override
    public void actualizarDatos(int id, String codigo_empleado, String nombre_empleado, String cargo) {
    
          if (id >= 0 && id < listaDatos.size()) {
            listaDatos.set(id, new String[]{codigo_empleado, nombre_empleado, cargo});
        }
    }

    @Override
    public void borrarDatos(int id) {
    
          if (id >= 0 && id < listaDatos.size()) {
            listaDatos.remove(id);
        }
    }

}

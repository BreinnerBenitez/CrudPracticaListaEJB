/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/SessionLocal.java to edit this template
 */
package SessionBean;

import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author SDH
 */
@Local
public interface curdtrabajoLocal {
    
    void agregarDatos(String codigo_empleado, String Nombre_empleado, String cargo); // Método para agregar datos
    List<String[]> obtenerDatos(); // Método para obtener todos los datos
    void actualizarDatos(int id, String codigo_empleado, String nombre_empleado, String cargo); // Método para actualizar datos
    void borrarDatos(int id); // Método para borrar datos
}

